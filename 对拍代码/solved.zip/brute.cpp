/*----------------------------------------------------------------

这个文件直接放暴力解法的代码
正确率100%
记得要先编译

----------------------------------------------------------------*/
#include <bits/stdc++.h>
using namespace std;
int main()
{
    int a, b, ans = 0;
    scanf("%d %d", &a, &b);
    for (int i = 1; i <= a; ++i)
        ans++;
    for (int i = 1; i <= b; ++i)
        ans++;
    cout << ans << endl;
}