/*----------------------------------------------------------------

这个文件造数据，只放造数据的代码
注意一定要先编译一遍再去点duipai.exe

----------------------------------------------------------------*/
#include<bits/stdc++.h>
#define YES cout<<"YES"<<endl
#define NO cout<<"NO"<<endl
#define fi first
#define se second
//#define int long long int
using namespace std;

typedef long long LL;
typedef unsigned long long ULL;
typedef pair<long long,long long> PII;
typedef pair<LL,LL> PLL;

int R(int maxValue,int minValue){//随机数生成
    return (rand()%(maxValue - minValue + 1)) + minValue;
}

int main(){
    srand(time(0));//伪随机
    //文件输入（写到文件里）
    int T = 1;//fin << T << endl;
    while(T--)
    {
        cout << R(9000,0) << " " << R(9000,1) << endl;
    }
    return 0;
}
